package com.novastream.tv

import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

/**
 * Minimal HTTP GET helper for pulling remote M3U playlists and XMLTV EPG
 * files that the user has explicitly supplied a URL for (preset or custom).
 * No proprietary resolvers, no auth bypass — a plain authenticated-by-URL fetch.
 */
object UrlFetcher {
    fun fetchText(urlString: String, connectTimeoutMs: Int = 15_000, readTimeoutMs: Int = 20_000): String {
        val url = URL(urlString)
        val connection = url.openConnection() as HttpURLConnection
        try {
            connection.connectTimeout = connectTimeoutMs
            connection.readTimeout = readTimeoutMs
            connection.requestMethod = "GET"
            connection.setRequestProperty("User-Agent", "NovaStreamTV/3.0")
            connection.instanceFollowRedirects = true

            val code = connection.responseCode
            if (code !in 200..299) {
                throw IllegalStateException("HTTP $code fetching $urlString")
            }
            return BufferedReader(InputStreamReader(connection.inputStream)).use { reader ->
                reader.readText()
            }
        } finally {
            connection.disconnect()
        }
    }
}

private fun BufferedReader.readText(): String {
    val sb = StringBuilder()
    var line: String?
    while (true) {
        line = readLine() ?: break
        sb.append(line).append('\n')
    }
    return sb.toString()
}

/** Built-in playlist source presets the user can select without typing a URL. */
data class SourcePreset(val label: String, val m3uUrl: String, val epgUrl: String?)

val NOVASTREAM_SOURCE_PRESETS = listOf(
    SourcePreset(
        label = "PerfectTV Free",
        m3uUrl = "https://ptv2026.com/PerfecttvFree3.m3u",
        epgUrl = "https://ptv2026.com/EPGPerfecttv/epgtvku.xml"
    ),
    SourcePreset(
        label = "iptv-org — All (free-to-air)",
        m3uUrl = "https://iptv-org.github.io/iptv/index.m3u",
        epgUrl = null
    ),
    SourcePreset(
        label = "iptv-org — Malaysia",
        m3uUrl = "https://iptv-org.github.io/iptv/countries/my.m3u",
        epgUrl = null
    )
    // Add more SourcePreset entries here for additional built-in sources.
)
